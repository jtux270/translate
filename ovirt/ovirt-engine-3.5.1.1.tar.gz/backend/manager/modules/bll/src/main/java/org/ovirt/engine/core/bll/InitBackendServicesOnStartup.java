package org.ovirt.engine.core.bll;

public interface InitBackendServicesOnStartup {

    public void create();
}
