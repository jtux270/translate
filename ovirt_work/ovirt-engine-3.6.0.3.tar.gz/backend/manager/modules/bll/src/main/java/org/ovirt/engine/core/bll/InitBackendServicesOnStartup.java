package org.ovirt.engine.core.bll;

public interface InitBackendServicesOnStartup {

    void create();
}
