See http://www.ovirt.org/index.php?title=CI/Build_and_test_standards
